
export interface Contacto {
  id: number;
  nombre: string;
  apellidos: string;
  email: string;
  telefono: string;
  genero: string;
}
